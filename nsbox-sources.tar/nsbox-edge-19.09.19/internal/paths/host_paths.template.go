// This file was auto-generated. DO NOT EDIT.
// Use 'gn args' to change the directories there instead.

package paths

const State = "@STATE_DIR"
const Libexec = "@LIBEXEC_DIR"
const Share = "@SHARE_DIR"
const ProductName = "@PRODUCT_NAME"
