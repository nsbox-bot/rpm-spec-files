# Building from source

## Requirements

You need:

- [Google's GN build system.](https://gn.googlesource.com/gn/)
- Ninja.
- Python 3.
- The Go compiler.
- A C compiler (for Go to invoke while building CGo code).
- systemd's development packages.

## Instructions

TODO
